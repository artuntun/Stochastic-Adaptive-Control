function prnt(time)

if nargin<1,
 fprintf('Hit any key \n');
 pause
else
 pause(time);
end;
