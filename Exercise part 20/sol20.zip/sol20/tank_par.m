C=153.938; % D=14cm
g=981;
al=0.5;
ao=0.8;

sigma_l=0.4411;
sigma_o=0.3159;
