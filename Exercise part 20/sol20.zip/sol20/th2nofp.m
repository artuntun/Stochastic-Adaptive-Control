function n=th2nofp(th)

n=length(th2par(th));
%n=sum(th(1,4:8));
