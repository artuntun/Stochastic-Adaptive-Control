function psignik(th)

p=th.ParameterVector;
P=th.CovarianceMatrix;
s2=th.NoiseVariance;
