disp('Velcome to 04342')
format compact
warning off
path(path,'/home/nkp/matlab/ctrl');
path('/home/nkp/matlab/pol',path);
path('/home/nkp/matlab/vec',path);
path('/home/nkp/matlab/sys',path);
path('/home/nkp/matlab/sig',path);
path('/home/nkp/matlab/plt',path);
path('/home/nkp/gpc/mlab/util',path);
path('/home/nkp/gpc/mlab/sim/priv',path);

