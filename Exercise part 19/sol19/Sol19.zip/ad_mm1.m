function [level,stat]=ad_mm1
%
% Dummy function - is not used in simulation
