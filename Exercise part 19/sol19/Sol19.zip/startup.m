disp('Welcome to 02421')
format compact
warning off
