C=153.938; % D=14cm
g=981;
al=0.5;
ao=0.8;

sigmal=0.4411;
sigmao=0.3159;
